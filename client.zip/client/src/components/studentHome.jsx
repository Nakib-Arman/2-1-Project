import React from 'react';

function studentHome() {
  return (
    <div>
      <h1>Welcome to My React App!</h1>
    </div>
  );
}

export default studentHome;
